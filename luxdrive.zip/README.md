# LuxDrive — локальный сайт + сервер

Коротко: проект — статический фронтенд с небольшим Node/Express сервером (`server.js`) и SQLite (`database.sqlite`).

Что я сделал:
- Добавил файлы конфигурации для деплоя: `.gitignore`, `Dockerfile`, `Procfile`, `.dockerignore`.
- Оставил все исходники в корне: `index.html`, `catalog.html`, `profile.html`, `style.css`, `script.js`, `server.js`.

Как запустить локально

1) Установить зависимости и запустить сервер:

```bash
npm install
npm start
```

Сервер по умолчанию слушает порт `3000`. Откройте: `http://localhost:3000`.

Ngrok — быстрый публичный доступ (для демонстрации)

Установите `ngrok` (https://ngrok.com/) и в отдельном терминале выполните:

```bash
# если сервер запущен на 3000
ngrok http 3000
```

Скопируйте `Forwarding` URL (https://...) — это публичная ссылка для просмотра вашего сайта.

Деплой (варианты)

- Статический (Netlify / GitHub Pages): если вы хотите деплоить только фронтенд (без API), можно направить репозиторий в Netlify и указать корень как `publish directory`.
- Серверный (Railway / Render / Heroku): подходит для `server.js` + SQLite. Пушьте репозиторий в GitHub и подключите сервис, укажите `web: node server.js` (Procfile) или прямо команду запуска.
- Docker: можно собрать образ и запустить контейнер (подходит для большинства облаков):

```bash
docker build -t luxdrive .
docker run -p 3000:3000 luxdrive
```

Как запушить на GitHub (если хотите, дайте URL репозитория и я подготовлю команды):

```bash
git init
git add .
git commit -m "Initial: prepare for deploy"
git branch -M main
git remote add origin https://github.com/YOUR_USER/YOUR_REPO.git
git push -u origin main
```

Если хотите, могу:
- автоматически подготовить репозиторий (коммиты) локально,
- сгенерировать Docker image и проверить запуск,
- подготовить инструкции по развертыванию на Railway и Netlify.

Скажите, что из этого выполнить прямо сейчас: `ngrok` демонстрация (нужен доступ на запуск), пуш в GitHub (нужен URL), или деплой на Railway (вам нужно подключить сервис). 
